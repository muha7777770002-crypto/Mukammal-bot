<?php
ob_start();
define('API_TOKEN', '7684259607:AAF03uFLiEeEeR1XWjiw4Rc7QdpF3lLC4Xg');
$ITACHI_UCHIHA_SONO_SHARINGAN = "2025400572";
/*
Ushbu kod 23.03.2025-yil @ITACHI_UCHIHA_SONO_SHARINGAN tomonidan yozildi 
kodda Kino sozlash bo'limi ishlamaydi o'zingiz tog'irlab olishingiz mumkun yokida to'g'irlash uchun  @ITACHI_UCHIHA_SONO_SHARINGAN profiliga Telegram orqali muroojat qiling
xabar yuborish 75k foydalanuvchigacha xech qanday baglarsiz ishlaydi 
Mehnatimni qadirlaysiz degan umiddaman !
Manba: @UZ_IT_CENTER
Tarqatildi @UZ_IT_CENTER

Foydalanuvchi uchun Bot funksiyalari:  (Tugmalar inline)
1. /search orqali fil izlash (kino kodi yoki nomi orqali)
2. /rek orqali Reklama matnini ko'rish
3./help orqali yordam olish
4. /dev orqali Dasturchi haqida ma'lumot olish
5.Kino qidirish tugmasi orqali kino qidirish (kino kodi yoki nomi orqali)
6. Kanaldan Tomoshqa qilish tugmasini bosish orqali animeni tomosha qilish
7. Ortga tugmasi orqali ortga qaytish
Admin panel uchun Bot funksiyalari: (Tugmalar inline)
1. Reklama matnini tahrirlash
2. Yordam matnini tahrirlash
3. Kinolarni uzatishni (yoqish yoki o'chirish)
4. Hozirgi bot holatini kuzatish
5. Botni foydalanuvchilar uchun o'chirish
6. Kino qo'shish
7. Qism qo'shish
8. Kino sozlash (Beta) // Muammolar tuzatilmagan
9. Kanal uchun post tayyorlash
10. Majburiy obunaga kanal qo'shish
11. Majburiy obunadagi kanallar ro'yhatini kuzatish
12. Majburiy obunadagi kanallarni o'chirish
13. Kino kanalni almashtirish
14.Bot statistikasini kuzatish
15. Foydalanuvchiga xabar yubrorish
17. Oddiy xabar yubrosih [Hamma foydalanuvchiga boradi] (Nechtafoydalanuvchiga borgani ko'rsatiladi)
16. Forwerd xabar yuborish [Hamma foydalanuvchiga boradi] (Nechtafoydalanuvchiga borgani ko'rsatiladi)
17. Orqaga tugmasi orqali admin apanelga qaytish
18. Admin uchun majburiy obuna so'ralmaydi 
Botdagi e'tiborsiz qoldirilgan muammolar
1. Orqaga tugmasi ba'zida ishlamasligi mumkun faqat Admin panel da
2. Kino sozlash tuzatilmagan !
*/
require_once "pdo.php";

// <-- @ITACHI_UCHIHA_SONO_SHARINGAN --> \\
function bot($m, $d = []) {
    $u = "https://api.telegram.org/bot" . API_TOKEN . "/" . $m;
    $c = curl_init($u);
    curl_setopt_array($c, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => (isset($d['photo']) && $d['photo'] instanceof CURLFile) ? $d : http_build_query($d)
    ]);
    $r = curl_exec($c);
    curl_close($c);
    return json_decode($r) ?: false;
}

function s($i, $t, $k = null) {
    bot('sendMessage', ['chat_id' => $i, 'text' => $t, 'reply_markup' => $k, 'parse_mode' => 'html']);
}

function e($i, $m, $t, $k = null) {
    bot('editMessageText', ['chat_id' => $i, 'message_id' => $m, 'text' => $t, 'reply_markup' => $k, 'parse_mode' => 'html']);
}

function del() {
    global $last_chat_id, $last_message_id;
    if ($last_chat_id && $last_message_id) bot('deleteMessage', ['chat_id' => $last_chat_id, 'message_id' => $last_message_id]);
}

$u = json_decode(file_get_contents('php://input'));
$msg = $u->message ?? $u->callback_query->message ?? null;
$cid = $msg->chat->id ?? null;
$mid = $msg->message_id ?? null;
$txt = $msg->text ?? '';
$fid = $u->message->from->id ?? $u->callback_query->from->id ?? null;
$d = $u->callback_query->data ?? '';
$ccid = $u->callback_query->message->chat->id ?? $cid;
$cmid = $u->callback_query->message->message_id ?? $mid;
$cfid = $u->callback_query->from->id ?? $fid;
$b = bot('getme')->result->username;
$ads = file_get_contents("data/ads.txt");
$share_i = file_get_contents("data/share.txt");
$movie_channel = file_get_contents("data/channel.txt");
$help = file_get_contents("data/help.txt");
$situation = file_get_contents("data/situation.txt");
$photo = $msg->photo;
$file = $photo[count($photo)-1]->file_id;
if (!$cid || !$fid) exit;

mkdir("step", 0777, true);
mkdir("data", 0777, true);
$step = file_get_contents("step/$cid.step") ?: '';

if ($txt) {
    if ($situation == "Off") {
        if ($cid == $ITACHI_UCHIHA_SONO_SHARINGAN) {
        } else {
            bot('sendMessage', [
                'chat_id' => $cid,
                'text' => "⚠️ <b>Bot vaqtincha ishlamayapti!</b>\n\n".
                          "<i>Hozirda texnik ishlar olib borilmoqda. Iltimos, keyinroq urinib ko'ring.</i> ✅",
                'parse_mode' => 'HTML',
            ]);
            exit();
        }
    }
}


function addUser($user_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE user_id = :user_id");
    $stmt->execute(['user_id' => $user_id]);
    $exists = $stmt->fetchColumn();

    if ($exists == 0) {
        $stmt = $pdo->prepare("INSERT INTO users (user_id, date) VALUES (:user_id, NOW())");
        $stmt->execute(['user_id' => $user_id]);
    }
}

function jc($u) {
    global $pdo, $ITACHI_UCHIHA_SONO_SHARINGAN;
    if($u == $ITACHI_UCHIHA_SONO_SHARINGAN){
        return true;
    }
    $channels = $pdo->query("SELECT channelId, channelLink FROM channels WHERE channelType = 'request'")->fetchAll(PDO::FETCH_ASSOC);
    if (!$channels) return true;

    $k = ['inline_keyboard' => []];
    $f = false;
    foreach ($channels as $i => $c) {
        $id = "-100" . $c['channelId'];
        $status = bot('getChatMember', ['chat_id' => $id, 'user_id' => $u])->result->status ?? 'left';
        $title = bot('getChat', ['chat_id' => $id])->result->title ?? explode('/', $c['channelLink'])[3];
        $k['inline_keyboard'][$i][0] = ['text' => in_array($status, ['creator', 'administrator', 'member']) ? "✅ $title" : "❌ $title", 'url' => $c['channelLink']];
        $f = $f || !in_array($status, ['creator', 'administrator', 'member']);
    }
    $k['inline_keyboard'][][0] = ['text' => '🔄 Tekshirish', 'callback_data' => 'c'];
    if ($f) {
        bot('sendMessage', ['chat_id' => $u, 'text' => "<b>⚠️Botdan to'liq foydlanish uchun kanallarga obuna bo'ling !</b>", 'reply_markup' => json_encode($k), 'parse_mode' => 'html']);
        return false;
    }
    return true;
}

function showMainMenu($chat_id, $message_id = null) {
    $k = json_encode(['inline_keyboard' => [[['text' => '🔎 Kino qidirish', 'callback_data' => 'search_movie']]]]);
    $t = "🎉 Assalomu aleykum @{$GLOBALS['b']} botimizga xush kelibsiz!\n<blockquote>Bu yerda kerakli bo'limni tanlang: \n● /search - 🎥 Film izlash\n● /rek - 📢 Reklama\n● /help - ❓ Yordam\n● /dev - 👨‍💻 Dasturchi</blockquote>";
    $message_id ? e($chat_id, $message_id, $t, $k) : s($chat_id, $t, $k);
}

function showAdminPanel($chat_id, $message_id = null) {
    $k = json_encode(['inline_keyboard' => [
        [['text' => '⚙️ Asosiy sozlamlar', 'callback_data' => 'main_settings']],
        [['text' => '🎬 Kino sozlamlari', 'callback_data' => 'movie_settings'],['text'=>"📝 Post tayyorlash",'callback_data'=>"createPost"]],
        [['text' => '📢 Kanallar', 'callback_data' => 'channel_settings'], ['text' => '📊 Statistika', 'callback_data' => 'stats']],
        [['text' => '✉ Xabar Yuborish', 'callback_data' => 'sendMessage']],
    ]]);
    $message_id ? e($chat_id, $message_id, "👨‍💼 <b>Admin panelga xush kelibsiz</b>\nBu yerda botni boshqarishingiz mumkun.", $k) : s($chat_id, "👨‍💼 <b>Admin panelga xush kelibsiz</b>\nBu yerda botni boshqarishingiz mumkun.", $k);
}

function search($type, $id, $message_id = null) {
    $t = "🔍 Kino nomini yoki kodini kiriting!";
    $k = json_encode(['inline_keyboard' => [[['text' => '🔙 Ortga', 'callback_data' => 'back']]]]);
    ($type == 'e' && $message_id) ? e($id, $message_id, $t, $k) : s($id, $t, $k);
    exit();
}

function sendToUser($ITACHI_UCHIHA_SONO_SHARINGAN_id, $user_id, $message) {
    if (!in_array($message, ['/start', '/panel', '/admin', '/search', '/rek', '/help', '/dev'])) {
        bot('sendMessage', ['chat_id' => $user_id, 'text' => $message, 'parse_mode' => 'html']);
        s($ITACHI_UCHIHA_SONO_SHARINGAN_id, "✅ Xabar muvaffaqiyatli yuborildi!");
    } else {
        s($ITACHI_UCHIHA_SONO_SHARINGAN_id, "❌ Komanda yuborish mumkin emas!");
    }
}

function broadcastMessage($ITACHI_UCHIHA_SONO_SHARINGAN_id, $message, $is_forward = false, $forward_mid = null) {
    global $pdo;
    if (!$is_forward && in_array($message, ['/start', '/panel', '/admin', '/search', '/rek', '/help', '/dev'])) {
        s($ITACHI_UCHIHA_SONO_SHARINGAN_id, "❌ Komanda yuborish mumkin emas!");
        return;
    }

    $users = $pdo->query("SELECT user_id FROM users")->fetchAll(PDO::FETCH_COLUMN);
    $total = count($users);
    $sent = 0;

    $msg = bot('sendMessage', ['chat_id' => $ITACHI_UCHIHA_SONO_SHARINGAN_id, 'text' => "Xabar yuborish boshlandi:\nXabar yuborilmoqda...\nYuborildi: 0/$total"]);
    $msg_id = $msg->result->message_id;

    foreach ($users as $user_id) {
        if ($is_forward && $forward_mid) {
            bot('forwardMessage', ['chat_id' => $user_id, 'from_chat_id' => $ITACHI_UCHIHA_SONO_SHARINGAN_id, 'message_id' => $forward_mid]);
        } else {
            bot('sendMessage', ['chat_id' => $user_id, 'text' => $message, 'parse_mode' => 'html']);
        }
        $sent++;
        if ($sent % 15 == 0 || $sent == $total) {
            e($ITACHI_UCHIHA_SONO_SHARINGAN_id, $msg_id, "Xabar yuborish boshlandi:\nXabar yuborilmoqda...\nYuborildi: $sent/$total");
            usleep(50000); 
        }
    }
    e($ITACHI_UCHIHA_SONO_SHARINGAN_id, $msg_id, "Xabar yuborish yakunlandi:\nYuborildi: $sent/$total");
}

if(file_exists("data/situation.txt")==false){
file_put_contents("data/situation.txt","On");
}
if(file_exists("data/channel.txt")==false){
file_put_contents("data/channel.txt","@KinoLiveUz");
}
if(file_exists("data/share.txt")==false){
file_put_contents("data/share.txt","false");
}
if (!file_exists("data/ads.txt")) {
    file_put_contents("data/ads.txt", "📢 *Reklama e'lonlari!*\n\n".
        "🎬 *Siz izlagan kinolar endi bir joyda!*\n\n".
        "🔹 /search orqali istalgan kinoni qidiring!\n".
        "🔹 Reklama berish uchun /rek buyrug‘idan foydalaning!\n".
        "🔹 Botimiz imkoniyatlaridan bepul bahramand bo‘ling!\n\n".
        "🔥 Hozir qo‘shiling va imkoniyatlardan foydalaning! 🔥\n\n".
        "👉 Yangiliklarni kuzatib boring va do‘stlaringizga ulashing! 🚀"
    );
}

if(file_exists("data/help.txt")==false){
file_put_contents("data/help.txt","ℹ️ Yordam bo‘limi

👋 Assalomu alaykum! Ushbu bot orqali kino qidirish, reklama joylashtirish, va dasturchi haqida ma'lumot olish imkoniyatiga egasiz.

🔹 📌 Asosiy buyruqlar:
🎬 Kino qidirish: /search – Istalgan kinoni osongina toping!
📢 Reklama berish: /rek – O‘z mahsulot yoki xizmatingizni reklama qiling!
👨‍💻 Dasturchi haqida ma'lumot: /dev – Botni kim yaratganini bilib oling!

🔹 🎬 Kino qidirish (Inline usulida):
Siz kinoni inline orqali qidirishingiz mumkin! @bot_username Kino nomi deb yozing va bot sizga mos variantlarni taklif qiladi.

🔹 📞 Qo‘llab-quvvatlash:
Agar sizga qo‘shimcha yordam kerak bo‘lsa, admin bilan bog‘laning:
📩 @ITACHI_UCHIHA_SONO_SHARINGAN

✅ Botdan samarali foydalaning va zavq oling! 😊
");
}




if ($txt == "/start") {
    unlink("step/$cid.step");
    addUser($fid);
    jc($cid) && showMainMenu($cid);
    exit();
}

if (($txt == "/search" || $d == "search_movie") && jc($cid) == 1) {
        file_put_contents("step/$ccid.step", 'search_movie');
    if ($txt == "/search") {
        search('s', $cid);
    } else {
        search('e', $ccid, $cmid);
    }
    exit();
}


if ((mb_stripos($txt, "/start ") !== false) && jc($cid) == 1) {
    $id = str_replace('/start ', '', $txt);

    if (jc($ccid) == 1) {
        if (!ctype_digit($id)) {
            s($ccid, "Noto‘g‘ri kino ID!");
            exit();
        }

        $stmt = $pdo->prepare("SELECT * FROM movie WHERE id = :id");
        $stmt->execute(['id' => $id]);
        $rel = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($rel) {
            $stmt = $pdo->prepare("SELECT * FROM movie_ep WHERE movie_id = :id ORDER BY episode ASC");
            $stmt->execute(['id' => $id]);

            $epizod_bormi = false; 
            do {
                $episode = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($episode) {
                    $caption = "🍿 *{$rel['name']}* 🍿\n";
                    $caption .= "✨───────────────✨\n";
                    $caption .= "🎥 *Qism:* {$episode['episode']} / {$rel['episode']}\n";
                    $caption .= "✨───────────────✨\n";
                    $caption .= "🎬 *Kino ID:* {$id}";

                    bot('sendVideo', [
                        'chat_id' => $ccid,
                        'video' => $episode['movie'],
                        'caption' => $caption,
                        'parse_mode' => 'Markdown',
                        'protect_content'=>$share_i
                    ]);
                    unlink("step/$ccid.step");
                    $epizod_bormi = true; 
                }
            } while ($episode);
            if (!$epizod_bormi) {
                s($ccid, "Bu kinoda qismlar topilmadi!");
                exit();
            }
        } else {
            s($ccid, "Bu kino topilmadi!");
        }
    }
}

if ($txt == "/dev" && jc($cid) == 1) {
    jc($cid) && s($cid, "👨‍💻 Bot dasturchisi: @ITACHI_UCHIHA_SONO_SHARINGAN\nShuncha mexnatimni hurmat qilasizlar degan umiddaman!", json_encode(['inline_keyboard' => [[['text' => '🔙 Ortga', 'callback_data' => 'back']]]]));
    exit();
}

if ($txt == "/help" && jc($cid) == 1) {
    jc($cid) && s($cid,$help, json_encode(['inline_keyboard' => [[['text' => '🔙 Ortga', 'callback_data' => 'back']]]]));
    exit();
}

if ($txt == "/rek" && jc($cid) == 1) {
    jc($cid) && s($cid,$ads, json_encode(['inline_keyboard' => [[['text' => '🔙 Ortga', 'callback_data' => 'back']]]]));
    exit();
}

if ($d == "c" && jc($cfid) == 1) {
    del();
    jc($cfid) && showMainMenu($ccid, $cmid);
    exit();
}

if ($step == 'search_movie' && jc($cid) == 1) {
if(isset($txt)){
    $stmt = $pdo->prepare(is_numeric($txt) ? "SELECT * FROM movie WHERE id = :id" : "SELECT * FROM movie WHERE name LIKE :name");
    $stmt->execute(is_numeric($txt) ? ['id' => $txt] : ['name' => "%$txt%"]);
    $results = is_numeric($txt) ? [$stmt->fetch(PDO::FETCH_ASSOC)] : $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($results && $results[0]) {
            $result = $results[0];
            bot('sendPhoto', [
                'chat_id' => $cid,
                'photo' => $result['image'],
                'caption' => "✨ *<b>Film ma'lumotlari</b>* ✨\n★ 🎥 <b>Nomi:</b> {$result['name']}\n★ 📼 <b>Qismlar:</b> {$result['episode']}\n★ 🗺 <b>Davlat:</b> {$result['country']}\n★ 🎙 <b>Til:</b> {$result['language']}\n★ 🔑 <b>Kino kodi:</b> {$result['id']}\n\n📢 <b>Kino kanal:</b> @KinoLiveUz",
                'parse_mode' => 'HTML',
                'reply_markup' => json_encode(['inline_keyboard' => [[['text' => 'Tomosha qilish', 'url' => "https://t.me/$b?start=" . $result['id']]]]])
            ]);
    } else {
        if(!isset($d)){
            s($cid, "❌ Bunday " . (is_numeric($txt) ? "ID" : "nom") . " bilan kino topilmadi!");
        }
        unlink("step/$ccid.step");
    }
    exit();
}
    exit();
}

// Admin Panel 
if (in_array($txt, ["/admin", "/panel"])) {
    if ($fid == $ITACHI_UCHIHA_SONO_SHARINGAN) {
        showAdminPanel($cid, null);
        exit();
    } else {
        s($cid, "❌ Siz admin emassiz!");
        exit();
    }
}

if ($d == "stats" && $cfid == $ITACHI_UCHIHA_SONO_SHARINGAN) {
    $user_count = $pdo->query("SELECT COUNT(*) as user_count FROM users")->fetch(PDO::FETCH_ASSOC)['user_count'];
    $ping = sys_getloadavg()[0];
    e($ccid, $cmid, "💡 <b>O'rtacha ping: <i>$ping</i></b>\n\n👤 Barcha Foydalanuvchilar: $user_count", json_encode(['inline_keyboard' => [[['text' => '🔙 Ortga', 'callback_data' => 'back']]]]));
    exit();
}

if ($d == 'movie_settings' && $cfid == $ITACHI_UCHIHA_SONO_SHARINGAN) {
    $k = json_encode(['inline_keyboard' => [
        [['text' => '🎥 Kino qo\'shish', 'callback_data' => 'add_movie']],
        [['text' => '📀 Qism qo\'shish', 'callback_data' => 'add-episode']],
        [['text' => '💡 Kino sozlash', 'callback_data' => 'edit-movie']],
        [['text' => '🔙 Ortga', 'callback_data' => 'back']]
    ]]);
    e($ccid, $cmid, "O'zingizga kerakli bo'lgan menuni tanlang", $k);
    exit();
}

if ($d == 'channel_settings' && $cfid == $ITACHI_UCHIHA_SONO_SHARINGAN) {
    $k = json_encode(['inline_keyboard' => [
        [['text' => '🔐 Majburiy obunalar', 'callback_data' => 'mandatory_subscriptions']],
        [['text' => '🎥 Kino kanal', 'callback_data' => 'movie_channel']],
        [['text' => '🔙 Ortga', 'callback_data' => 'back']]
    ]]);
    e($ccid, $cmid, "O'zingizga kerakli bo'lgan menuni tanlang", $k);
    exit();
}

if ($d == 'main_settings' && $cfid == $ITACHI_UCHIHA_SONO_SHARINGAN) {
    $file_share = file_get_contents("data/share.txt");
    if ($file_share == 'true') {
        $share = "✅  Uzatishni yoqish";
    } elseif ($file_share == 'false') {
        $share = "❌ Uzatishni o'chirish";
    }

$k = json_encode(['inline_keyboard' => [
    [['text' => "📢 Reklama matni", 'callback_data' => 'ads_text'], ['text' => "ℹ️ Yordam matni", 'callback_data' => 'help_text']],
    [['text' => $share, 'callback_data' => 'share'], ['text' => "📝 Hozirgi holat", 'callback_data' => 'now_about']],
    [['text'=>"🤖 Bot holati",'callback_data'=>'bot_info']],
    [['text' => '🔙 Ortga', 'callback_data' => 'back']]
]]);


    e($ccid, $cmid, "⚙️ Asosiy sozlamalar bo'limiga xush kelibsiz !", $k);
    exit();
}

if($d == 'ads_text'){
    e($ccid,$cmid,"/rek komandasi uchun reklama matnini kiriting !");
    file_put_contents("step/$ccid.step",ads_text);
    exit();
}
if($step == 'ads_text'){
    if(isset($txt)){
        file_put_contents("data/ads.txt",$txt);
    }
    s($cid,"✅ Reklama matni muvoffaqatli qabul qilindi !");
    exit();
}
if($d == 'help_text'){
    e($ccid,$cmid,"/help komandasi uchun Yordam matnini kiriting !");
    file_put_contents("step/$ccid.step",help_text);
    exit();
}
if($step == 'help_text'){
    if(isset($txt)){
        file_put_contents("data/help.txt",$txt);
    }
    s($cid,"✅ Yordam matni muvoffaqatli qabul qilindi !");
    exit();
}
if($d == 'share'){
    $file_share = file_get_contents("data/share.txt");
    if ($file_share == 'true') {
        file_put_contents("data/share.txt",'false');
    e($ccid,$cmid,"Kino uzatish muvoffaqatli o'chirildi ✅",json_encode(['inline_keyboard'=>[[['text' => '🔙 Ortga', 'callback_data' => 'back']]]]));
    } elseif ($file_share == 'false') {
        file_put_contents("data/share.txt",'true');
    e($ccid,$cmid,"Kino uzatish muvoffaqatli yoqildi ✅",json_encode(['inline_keyboard'=>[[['text' => '🔙 Ortga', 'callback_data' => 'back']]]]));
    }
    exit();
}
if ($d == 'now_about') {
if($share_i == 'false'){
    $uzatish = "Yoqilgan ✅";
} elseif($share_id == 'true'){
    $uzatish = "O'chirilgan ❌";
}
e($ccid, $cmid, "<b>Bot ma'lumotlari:</b>\n\n🔹 <b>Reklama matni:</b>\n$ads\n\nℹ️ <b>Yordam matni:</b>\n$help \n\n📤 <b>Uzatish holati:</b> $uzatish\n\n<b>🎥 Kino kanal:</b><i>$movie_channel</i> ",json_Encode(['inline_keyboard'=>[[['text' => '🔙 Ortga', 'callback_data' => 'back']]]]));
$movie_channel = nl2br(file_get_contents("data/channel.txt"));
}
$situation = file_get_contents("data/situation.txt");
if($situation == 'On'){
    $bot_holat = 'Yoqilgan ✅';
} elseif($situation == 'Off'){
    $bot_holat = "O'chirilgan ❌";
}
if($situation == 'On'){
    $bot_situation = "O'chirish ❌";
} elseif($situation == 'Off'){
    $bot_situation = 'Yoqish ✅';
}

if($d == 'bot_info'){
    e($ccid,$cmid,"<b>Bot holati:</b> <i>$bot_holat</i>",json_encode([
        'inline_keyboard'=>[
            [['text'=>$bot_situation,'callback_data'=>'bot_change']],
            [['text' => '🔙 Ortga', 'callback_data' => 'back']],
            ],
        ]));
}
if($d == 'bot_change'){
    if($situation == 'On'){
    file_put_contents("data/situation.txt",'Off');
    e($ccid,$cmid,"Bot muvoffaqatli o'chirildi ✅",json_encode([
        'inline_keyboard'=>[
            [['text'=>$bot_situation,'callback_data'=>'bot_change']],
            ],
        ]));
} elseif($situation == 'Off'){
    file_put_contents("data/situation.txt",'On');
    e($ccid,$cmid,"Bot muvoffaqatli yoqildi ✅",json_encode([
        'inline_keyboard'=>[
            [['text'=>$bot_situation,'callback_data'=>'bot_change']],
            [['text' => '🔙 Ortga', 'callback_data' => 'back']]
            ],
        ]));
}
}

if($d == 'movie_channel'){
    e($ccid,$cmid,"Post yuboriladigan kino kanal userini kiriting\n<b>Na'muna: @KinoLiveUz</b>",json_encode([
            'inline_keyboard'=>[
                [['text' => '🔙 Ortga', 'callback_data' => 'back']],
                ],
            ]));
        file_put_contents("step/$ccid.step",'movie_channel');
        exit();
}

if ($step == 'movie_channel') {
    if (isset($txt) && empty($d)) { 
        file_put_contents("data/channel.txt", $txt);
        s($cid, "✅ Kino kanal muvaffaqiyatli qo'shildi!");
        unlink("step/$cid.step"); 
    }
    exit();
}

if ($d == 'mandatory_subscriptions') {
    e($ccid, $cmid, "O'zingizga kerakli tugmalardan birini tanlang", json_encode([
        'inline_keyboard' => [
            [['text' => "➕ Qo'shish", 'callback_data' => 'add_m_channel']],
            [['text' => "📃 Ro'yxat", 'callback_data' => 'list_m_channels'], ['text' => "🗑 O'chirish", 'callback_data' => 'delete_m_channel']],
            [['text' => '🔙 Ortga', 'callback_data' => 'back']],
        ]
    ]));
}

if ($d == 'add_m_channel') {
    e($ccid, $cmid, "Kanal ID sini kiriting (-100 qo'ymasdan)");
    file_put_contents("step/$ccid.step", "chann1");
}

if ($step == 'chann1' && !empty($txt)) {
    file_put_contents("step/$ccid.channel_id", $txt);
    s($cid, "Kanal havolasini kiriting (https://t.me bilan)");
    file_put_contents("step/$ccid.step", "chann2");
}

if ($step == 'chann2' && !empty($txt)) {
    $channelId = file_get_contents("step/$ccid.channel_id");
    $channelLink = $txt;
    $stmt = $pdo->prepare("INSERT INTO channels (channelId, channelLink, channelType) VALUES (?, ?, 'request')");
    $stmt->execute([$channelId, $channelLink]);
    s($cid, "✅ Kanal muvaffaqiyatli qo'shildi!");
    unlink("step/$ccid.step");
    unlink("step/$ccid.channel_id");
}

if ($d == 'list_m_channels') {
    $stmt = $pdo->query("SELECT id, channelLink FROM channels WHERE channelType = 'request'");
    $channels = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!$channels) {
        e($ccid, $cmid, "📭 Majburiy obuna kanallari yo'q!");
        exit();
    }
    
    $text = "📃 Majburiy obuna kanallari:\n\n";
    foreach ($channels as $i => $channel) {
        $text .= ($i + 1) . ". <a href='" . $channel['channelLink'] . "'>Kanal</a>\n";
    }
    e($ccid, $cmid, $text, json_encode(['parse_mode' => 'HTML']));
}

if ($d == 'delete_m_channel') {
    $stmt = $pdo->query("SELECT id, channelId, channelLink FROM channels WHERE channelType = 'request'");
    $channels = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!$channels) {
        e($ccid, $cmid, "📭 O'chirish uchun kanal yo'q!");
        exit();
    }
    
    $buttons = [];
    $text = "🗑 O'chirish uchun kanallarni tanlang:\n\n";
    
    foreach ($channels as $i => $channel) {
        $text .= ($i + 1) . ". <b>" . htmlspecialchars($channel['channelLink']) . "</b>\n"; 
        $buttons[] = [['text' => (string) ($i + 1), 'callback_data' => 'del_m_channel_' . $channel['id']]];
    }
    
    e($ccid, $cmid, $text, json_encode(['inline_keyboard' => $buttons]), 'html');
}

if (strpos($d, 'del_m_channel_') === 0) {
    $channelId = str_replace('del_m_channel_', '', $d);
    $stmt = $pdo->prepare("DELETE FROM channels WHERE id = ?");
    $stmt->execute([$channelId]);
    e($ccid, $cmid, "✅ Kanal muvaffaqiyatli o'chirildi!");
}

if ($d == 'add_movie') {
    e($cid, $cmid, "🎥 Kino nomini kiriting:");
    file_put_contents("step/$cid.step", "movie_name");
}

if ($step == 'movie_name') {
    if (!empty($txt)) {
        file_put_contents("data/movie_name_$cid.txt", $txt);
        s($cid, "💀 Kino qismlar sonini kiriting:");
        file_put_contents("step/$cid.step", "movie_episode");
    } else {
        s($cid, "❌ Iltimos, kino nomini kiriting!");
    }
}

if ($step == 'movie_episode') {
    if (!empty($txt) && is_numeric($txt)) {
        file_put_contents("data/movie_episode_$cid.txt", $txt);
        s($cid, "🌍 Kino chiqarilgan davlatni kiriting:");
        file_put_contents("step/$cid.step", "movie_country");
    } else {
        s($cid, "❌ Iltimos, faqat son kiriting!");
    }
}

if ($step == 'movie_country') {
    if (!empty($txt)) {
        file_put_contents("data/movie_country_$cid.txt", $txt);
        s($cid, "🔦 Kino tilini kiriting:");
        file_put_contents("step/$cid.step", "movie_language");
    } else {
        s($cid, "❌ Iltimos, kino chiqarilgan davlatni kiriting!");
    }
}

if ($step == 'movie_language') {
    if (!empty($txt)) {
        file_put_contents("data/movie_language_$cid.txt", $txt);
        s($cid, "🖼 Kino rasmi yuboring:");
        file_put_contents("step/$cid.step", "movie_image");
    } else {
        s($cid, "❌ Iltimos, kino tilini kiriting!");
    }
}

if ($step == 'movie_image') {
    if(isset($msg->photo)){
$file_id = $msg->photo[count($msg->photo)-1]->file_id;
        $name = file_get_contents("data/movie_name_$cid.txt");
        $episode = file_get_contents("data/movie_episode_$cid.txt");
        $country = file_get_contents("data/movie_country_$cid.txt");
        $language = file_get_contents("data/movie_language_$cid.txt");
        $create_at = date("H:i d.m.Y");

        try {
            $stmt = $pdo->prepare("INSERT INTO movie (name, episode, country, language, image, create_at) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$name, $episode, $country, $language, $file_id, $create_at]);
            $movie_id = $pdo->lastInsertId();

            unlink("data/movie_name_$cid.txt");
            unlink("data/movie_episode_$cid.txt");
            unlink("data/movie_country_$cid.txt");
            unlink("data/movie_language_$cid.txt");
            unlink("step/$cid.step");

            s($cid, "<b>✅ Kino muvaffaqiyatli qo‘shildi!</b>\n\n"
                . "🎮 <b>Kino nomi:</b> $name\n"
                . "💀 <b>Qismlar:</b> $episode\n"
                . "🌍 <b>Davlat:</b> $country\n"
                . "🔦 <b>Til:</b> $language\n"
                . "🕒 <b>Yaratilgan vaqt:</b> $create_at\n\n"
                . "🄚 <b>Kino kodi:</b> <code>$movie_id</code>");
        } catch (PDOException $e) {
            s($cid, "<b>⚠️ Xatolik!</b>\n\n<code>" . $e->getMessage() . "</code>");
            unlink("data/movie_name_$cid.txt");
            unlink("data/movie_episode_$cid.txt");
            unlink("data/movie_country_$cid.txt");
            unlink("data/movie_language_$cid.txt");
        }
    } else {
        s($cid, "❌ Iltimos, kino rasmini yuboring!");
    }
    exit();
}

if ($d == "add-episode") {
    del();
    e($ccid, $cmid, "<b>🔢 Kino kodini kiriting:</b>");
    file_put_contents("step/$ccid.step", "episode-code");
}

if ($step == "episode-code") {
    if (is_numeric($txt)) {
        $txt = $pdo->quote($txt);
        file_put_contents("step/test.txt", $txt);
        s($cid, "<b>🎥 Ushbu kodga tegishlik kino qismini yuboring:</b>");
        file_put_contents("step/$cid.step", "episode-video");
        exit();
    }
}

if ($step == "episode-video") {
    if (isset($msg->video)) {
        $file_id = $msg->video->file_id;
        $id = trim(file_get_contents("step/test.txt"), "'");
        
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM movie_ep WHERE movie_id = ?");
        $stmt->execute([$id]);
        $qismi = $stmt->fetchColumn() + 1;
        $sana = date('H:i:s d.m.Y');
        
        $stmt = $pdo->prepare("INSERT INTO movie_ep (movie_id, movie, episode) VALUES (?, ?, ?)");
        if ($stmt->execute([$id, $file_id, $qismi])) {
            s($cid, "<b>✅ $id raqamli kinoga $qismi-qism yuklandi!</b>\n\n<i>Yana yuklash uchun keyingi qismni yuborsangiz bo'ldi</i>");
            exit();
        } else {
            sms($cid, "<b>⚠️ Xatolik!</b>\n\n<code>" . implode(" ", $stmt->errorInfo()) . "</code>", $panel);
            unlink("step/$cid.step");
            unlink("step/test.txt");
            exit();
        }
    }
}

if ($d == "edit-movie") {
    e($ccid, $cmid, "<b>Tahrirlamoqchi bo'lgan movieni tanlang:</b>", json_encode([
        'inline_keyboard' => [
            [['text' => "Kino ma'lumotlarini", 'callback_data' => "editType-movies"]],
            [['text' => "Kino qismini", 'callback_data' => "editType-movie_datas"]]
        ]
    ]));
    file_put_contents("step/$ccid.step", "edit-movie");
}

if (mb_stripos($d, "editType-") !== false) {
    $ex = explode("-", $d)[1];
    file_put_contents("step/$ccid.tip", $ex);
    e($ccid, $cmid, "<b>Kino kodini kiriting:</b>");
    file_put_contents("step/$ccid.step", "edit-movies");
}

if ($step == "edit-movies") {
    $tip = file_get_contents("step/$ccid.tip");

    $stmt = $pdo->prepare("SELECT * FROM movie WHERE id = :id");
    $stmt->execute(['id' => $txt]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row) {
        if ($tip == "movies") {
            $kb = json_encode([
                'inline_keyboard' => [
                    [['text' => "Nomini tahrirlash", 'callback_data' => "editmovie-nom-$txt"]],
                    [['text' => "Qismini tahrirlash", 'callback_data' => "editmovie-qismi-$txt"]],
                    [['text' => "Davlatini tahrirlash", 'callback_data' => "editmovie-davlat-$txt"]],
                    [['text' => "Tilini tahrirlash", 'callback_data' => "editmovie-tili-$txt"]],
                    [['text' => "Yilini tahrirlash", 'callback_data' => "editmovie-yili-$txt"]],
                    [['text' => "Janrini tahrirlash", 'callback_data' => "editmovie-janri-$txt"]],
                ]
            ]);
            e($ccid, $cmid, "<b>❓ Nimani tahrirlamoqchisiz?</b>", $kb);
        } else {
            e($ccid, $cmid, "<b>Qism raqamini yuboring:</b>");
            file_put_contents("step/$ccid.step", "movie-epEdit=$txt");
        }
    } else {
        s($ccid, "❗ movie mavjud emas, qayta urinib ko'ring!");
    }
}

if (mb_stripos($step, "movie-epEdit=") !== false) {
    $ex = explode("=", $step);
    $id = $ex[1];

    $stmt = $pdo->prepare("SELECT * FROM movie_datas WHERE id = :id AND qism = :qism");
    $stmt->execute(['id' => $id, 'qism' => $txt]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row) {
        $kb = json_encode([
            'inline_keyboard' => [
                [['text' => "movie kodini tahrirlash", 'callback_data' => "editEpisode-id-$id-$txt"]],
                [['text' => "Qismini tahrirlash", 'callback_data' => "editEpisode-qism-$id-$txt"]],
                [['text' => "Videoni tahrirlash", 'callback_data' => "editEpisode-file_id-$id-$txt"]],
            ]
        ]);
        e($ccid, $cmid, "<b>❓ Nimani tahrirlamoqchisiz?</b>", $kb);
    } else {
        s($ccid, "❗ Ushbu movieda $txt-qism mavjud emas, qayta urinib ko'ring.");
    }
}

if (mb_stripos($d, "editmovie-") !== false) {
    e($ccid, $cmid, "<b>Yangi qiymatini kiriting:</b>");
    file_put_contents("step/$ccid.step", $d);
}

if (mb_stripos($step, "editmovie-") !== false) {
    $ex = explode("-", $step);
    $tip = $ex[1];
    $id = $ex[2];

    if ($tip == "qismi" || $tip == "yili") {
        if (is_numeric($txt)) {
            $stmt = $pdo->prepare("UPDATE movielar SET `$tip` = :val WHERE id = :id");
            $stmt->execute(['val' => $txt, 'id' => $id]);
            s($ccid, "✅ Saqlandi.");
        } else {
            s($ccid, "❗ Faqat raqamlardan foydalaning.");
        }
    } else {
        $stmt = $pdo->prepare("UPDATE movielar SET `$tip` = :val WHERE id = :id");
        $stmt->execute(['val' => $txt, 'id' => $id]);
        s($ccid, "✅ Saqlandi.");
    }
    unlink("step/$ccid.step");
}

if (mb_stripos($d, "editEpisode-") !== false) {
    e($ccid, $cmid, "<b>Yangi qiymatini kiriting:</b>");
    file_put_contents("step/$ccid.step", $d);
}

if (mb_stripos($step, "editEpisode-") !== false) {
    $ex = explode("-", $step);
    $tip = $ex[1];
    $id = $ex[2];
    $qism_raqami = $ex[3];

    if ($tip == "file_id") {
        if (isset($message->video)) {
            $file_id = $message->video->file_id;
            $stmt = $pdo->prepare("UPDATE movie_datas SET `file_id` = :file_id WHERE id = :id AND qism = :qism");
            $stmt->execute(['file_id' => $file_id, 'id' => $id, 'qism' => $qism_raqami]);
            s($ccid, "✅ Saqlandi.");
        } else {
            s($ccid, "❗ Faqat videodan foydalaning.");
        }
    } else {
        if (is_numeric($txt)) {
            $stmt = $pdo->prepare("UPDATE movie_datas SET `$tip` = :val WHERE id = :id AND qism = :qism");
            $stmt->execute(['val' => $txt, 'id' => $id, 'qism' => $qism_raqami]);
            s($ccid, "✅ Saqlandi.");
        } else {
            s($ccid, "❗ Faqat raqamlardan foydalaning.");
        }
    }
    unlink("step/$ccid.step");
}

if ($d == 'createPost') {
    e($ccid, $cmid, "Kino ID sini kiriting:");
    file_put_contents("step/$ccid.step", "movie_post_create");
    exit();
}
if ($step == 'movie_post_create') {
    $id = trim($txt);
    // To‘g‘ri PDO prepared statement
    $stmt = $pdo->prepare("SELECT * FROM movie WHERE id = :id");
    $stmt->execute(['id' => $id]);
    $movie = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($movie !== false && !empty($movie)) { // To‘g‘ri tekshirish
        $caption = "🎥 *{$movie['name']}* 🎥\n";
        $caption .= "╔════════════════╗\n";
        $caption .= "║ 🎞 Qism: {$movie['episode']}\n";
        $caption .= "║ 🌍 Davlat: {$movie['country']}\n";
        $caption .= "║ 🗣 Til: {$movie['language']}\n";
        $caption .= "╚════════════════╝";

        bot('sendPhoto', [
            'chat_id' => $ccid,
            'photo' => $movie['image'],
            'caption' => $caption,
            'parse_mode' => 'Markdown',
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [['text' => "$movie_channel ga yuborish", 'callback_data' => "sendPost1=$id"]],
                ]
            ]),
        ]);
    } else {
       if(!isset($d)){
            s($ccid, "❌ Ushbu ID bilan kino topilmadi, qayta urinib ko‘ring!");
       }
    }
}

if (mb_stripos($d, "sendPost1=") !== false) {
    $id = str_replace("sendPost1=", "", $d);
    $stmt = $pdo->prepare("SELECT name, episode, country, language, image FROM movie WHERE id = :id");
    $stmt->execute(['id' => $id]);
    $movie = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($movie !== false && !empty($movie)) { 
        $caption = "🎥 *{$movie['name']}* 🎥\n";
        $caption .= "╔════════════════╗\n";
        $caption .= "║ 🎞 Qism: {$movie['episode']}\n";
        $caption .= "║ 🌍 Davlat: {$movie['country']}\n";
        $caption .= "║ 🗣 Til: {$movie['language']}\n";
        $caption .= "╚════════════════╝";

        bot('sendPhoto', [
            'chat_id' => $movie_channel,
            'photo' => $movie['image'],
            'caption' => $caption,
            'parse_mode' => 'Markdown',
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [['text' => "🔷 Tomosha qilish 🔷", 'url' => "https://t.me/MyBot?start=$id"]], // @MyBot ni o‘zingizning bot username bilan almashtiring
                ]
            ]),
        ]);
        s($ccid, "✅ Postingiz muvaffaqiyatli kanalga yuborildi!");
    } else {
        if(!isset($d)){
                    s($ccid, "❌ Ushbu ID bilan anime topilmadi!");
        }
    }
    unlink("step/$ccid.step");
    exit();
}
if ($d == 'sendMessage' && $cfid == $ITACHI_UCHIHA_SONO_SHARINGAN) {
    $k = json_encode(['inline_keyboard' => [
        [['text' => '👤 Userga', 'callback_data' => 'user_message']],
        [['text' => '👥 Oddiy xabar', 'callback_data' => 'simple_message']],
        [['text' => '📩 Forward xabar', 'callback_data' => 'forward_message']],
        [['text' => '🔙 Ortga', 'callback_data' => 'back']]
    ]]);
    e($ccid, $cmid, "O'zingizga kerakli xabar turini tanlang !:", $k);
    exit();
}

if ($d == "user_message" && $cfid == $ITACHI_UCHIHA_SONO_SHARINGAN) {
    e($ccid,$cmid, "Foydalanuvchi ID sini kiriting:");
    file_put_contents("step/$ccid.step", 'waiting_user_id');
    exit();
}

if ($step == 'waiting_user_id' && $fid == $ITACHI_UCHIHA_SONO_SHARINGAN && $txt) {
    file_put_contents("step/$cid.step", "waiting_message_$txt");
    s($cid, "Foydalanuvchiga yuboriladigan xabarni kiriting:");
    exit();
}

if (preg_match('/waiting_message_(\d+)/', $step, $matches) && $fid == $ITACHI_UCHIHA_SONO_SHARINGAN && $txt) {
    $user_id = $matches[1];
    sendToUser($cid, $user_id, $txt);
    unlink("step/$cid.step");
    exit();
}

if ($d == "simple_message" && $cfid == $ITACHI_UCHIHA_SONO_SHARINGAN) {
    e($ccid,$cmid, "Hamma foydalanuvchilarga yuboriladigan xabarni kiriting:");
    file_put_contents("step/$ccid.step", 'waiting_broadcast');
    exit();
}

if ($step == 'waiting_broadcast' && $fid == $ITACHI_UCHIHA_SONO_SHARINGAN && $txt) {
    broadcastMessage($cid, $txt);
    unlink("step/$cid.step");
    exit();
}

if ($d == "forward_message" && $cfid == $ITACHI_UCHIHA_SONO_SHARINGAN) {
    e($ccid,$cmid, "Forward qilinadigan xabarni yuboring:");
    file_put_contents("step/$ccid.step", 'waiting_forward_message');
    exit();
}

if ($step == 'waiting_forward_message' && $fid == $ITACHI_UCHIHA_SONO_SHARINGAN) {
    $forward_mid = $mid;
    broadcastMessage($cid, null, true, $forward_mid);
    unlink("step/$cid.step");
    exit();
}

if ($d == 'back') {
    unlink("step/$ccid.step");
    ($cfid == $ITACHI_UCHIHA_SONO_SHARINGAN) ? showAdminPanel($ccid, $cmid) : showMainMenu($ccid, $cmid);
    exit();
}
?>
<?php
try {
    // PDO ulanishini sozlash
    $pdo = new PDO("mysql:host=localhost;dbname=moviebot", "moviebot", "moviebot123");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("SET NAMES 'utf8mb4'");

    // Channels jadvalini yaratish
    $sql = "CREATE TABLE IF NOT EXISTS channels (
        id INT NOT NULL AUTO_INCREMENT,
        channelId VARCHAR(130) NOT NULL,
        channelLink VARCHAR(300) NOT NULL,
        channelType VARCHAR(25) NOT NULL,
        PRIMARY KEY (id)
    ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci";
    $pdo->exec($sql);
    echo "✅ Channels jadvali muvaffaqiyatli yaratildi!<br>";

    // Movie jadvalini yaratish
    $sql = "CREATE TABLE IF NOT EXISTS movie (
        id INT NOT NULL AUTO_INCREMENT,
        name TEXT NOT NULL,
        episode TEXT NOT NULL,
        country TEXT NOT NULL,
        language TEXT NOT NULL,
        image TEXT NOT NULL,
        create_at VARCHAR(430) NOT NULL,
        PRIMARY KEY (id)
    ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci";
    $pdo->exec($sql);
    echo "✅ Movie jadvali muvaffaqiyatli yaratildi!<br>";

    // Movie_ep jadvalini yaratish
    $sql = "CREATE TABLE IF NOT EXISTS movie_ep (
        id INT NOT NULL AUTO_INCREMENT,
        movie_id TEXT NOT NULL,
        movie TEXT NOT NULL,
        episode TEXT NOT NULL,
        PRIMARY KEY (id)
    ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci";
    $pdo->exec($sql);
    echo "✅ Movie_ep jadvali muvaffaqiyatli yaratildi!<br>";

    // Users jadvalini yaratish
    $sql = "CREATE TABLE IF NOT EXISTS users (
        id INT NOT NULL AUTO_INCREMENT,
        user_id VARCHAR(300) NOT NULL,
        date VARCHAR(50) NOT NULL,
        PRIMARY KEY (id)
    ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci";
    $pdo->exec($sql);
    echo "✅ Users jadvali muvaffaqiyatli yaratildi!<br>";

} catch (PDOException $e) {
    die("Xatolik: " . $e->getMessage());
}
?>